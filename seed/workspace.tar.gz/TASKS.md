# Known bugs

This is the Bottle web framework. Run the full test suite with `python3 -W ignore -m unittest`.

## BUG-1: Static files never revalidate

When a browser or CDN revalidates a static file with several ETags in If-None-Match, it never gets a 304 and re-downloads the whole file. A strict caching proxy also logs our ETag header as malformed.

Check: `python3 -W ignore -m unittest test.test_sendfile.TestSendFile.test_etag`

## BUG-2: Unnamed typed route placeholders crash

A route with an unnamed typed placeholder such as `/item/<:int>` returns a 500 (KeyError) on every request, instead of matching `/item/5` and returning 400 for `/item/abc`. Plain `<>` placeholders work.

Check: `python3 -W ignore -m unittest test.test_router.TestRouter.testAnonWildcard`

## BUG-3: Templates break when `end` shares a line

SimpleTemplate templates fail to compile when `end` shares a line with other code, e.g. `% if x:` followed by `%   do(); end`. An `end` on its own line works.

Check: `python3 -W ignore -m unittest test.test_stpl.TestSTPLDir.test_end_keyword_on_same_line`

## BUG-4: Uploads fail with mixed-case boundaries

File uploads and multipart form posts fail with 'Stream does not contain boundary' whenever the client's boundary contains uppercase letters, as browser-generated boundaries usually do.

Check: `python3 -W ignore -m unittest test.test_environ.TestRequest.test_multipart`
